const mongoose = require('mongoose')

var PostMessage = mongoose.model('PostMessage',
{
    user_name: {
        type:String
    },
    mobile_no:{
        type:String
    },
    user_email : {
        type:String
    },
    password:{
        type:String
    }

},'signup')

var postBookticket = mongoose.model('postBookticket',
{
    bus_type:{  type:String},
                    source:{type:String},
                    destination: {type:String},
                    ddate:{  type:String} ,
                    departure_time: {  type:String},
                    arrival_time: {  type:String},
                    fare: {  type:String},
                    stops: {  type:String},
                    available_seats: {  type:String},
                    status: {  type:String},
                    booking: {  type:String}
    // from: {
    //     type:String
    // },
    // to : {
    //     type:String
    // },
    // date:{
    //     type:Date
    // }
},'BookTicket')




module.exports = {PostMessage, postBookticket}