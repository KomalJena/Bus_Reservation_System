var postBookticket = mongoose.model('postBookticket',
{
    from: {
        type:String
    },
    to : {
        type:String
    },
    date:{
        type:Date
    }
},'BookTicket')

module.exports = { postBookticket }