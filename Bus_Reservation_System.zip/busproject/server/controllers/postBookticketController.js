const express = require('express')
var router = express.Router()
var ObjectID = require('mongoose').Types.ObjectId

var { postBookticket } = require('../models/postMessage')


router.get('/', (req, res) => {
    postBookticket.find((err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while retrieving all records : ' + JSON.stringify(err, undefined, 4))
    })
})

router.post('/', (req, res) => {
    var newRecord = new postBookticket({
        bus_type: req.body.bus_type,
        source: req.body.source,
        destination: req.body.destination,
        ddate: req.body.ddate,
        departure_time: req.body.departure_time,
        arrival_time: req.body.arrival_time,
        fare: req.body.fare,
        stops: req.body.stops,
        available_seats: req.body.available_seats,
        status: req.body.status,
        booking: req.body.booking
    })

    newRecord.save((err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while creating new record : ' + JSON.stringify(err, undefined, 4))
    })
})

// router.put('/:id', (req, res) => {
//     if (!ObjectID.isValid(req.params.id))
//         return res.status(400).send('No record with given id : ' + req.params.id)

//     var updatedRecord = {
//         from: req.body.from,
//         to: req.body.to,
//         date: req.body.date
//     }

//     postBookticket.findByIdAndUpdate(req.params.id, { $set: updatedRecord }, { new: true }, (err, docs) => {
//         if (!err) res.send(docs)
//         else console.log('Error while updating a record : ' + JSON.stringify(err, undefined, 4))
//     })
// })



router.delete('/:id', (req, res) => {
    if (!ObjectID.isValid(req.params.id))
        return res.status(400).send('No record with given id : ' + req.params.id)

        postBookticket.findByIdAndRemove(req.params.id, (err, docs) => {
        if (!err) res.send(docs)
        else console.log('Error while deleting a record : ' + JSON.stringify(err, undefined, 4))
    })
})


module.exports = router