import React from 'react';

import './App.css';
import Landingpage from './components/Main';


function App() {
  return (
    <div className="App">
   <Landingpage/>
    </div>
  );
}

export default App;
