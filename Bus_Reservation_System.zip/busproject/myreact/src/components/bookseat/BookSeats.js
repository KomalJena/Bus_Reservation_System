import React from 'react';
import { Link } from "react-router-dom";
import './seatbook.css';
import DrawGrid from './DrawGrid';
class BookSeat extends React.Component {

  constructor() {
    super();
    this.state = {
      seat: [
        '1', '2', '3', '4', '5', '6',
        '7', '8', '9', '10', '11', '12',
        '13', '14', '15', '16', '17', '18', '19', '20',
        '21', '22', '23', '24', '25', '26',
        '27', '28', '29', '30', '31', '32',
        '33', '34', '35', '36', '37', '38', '39', '40'
      ],
      seatAvailable: [
        '1', '2', '3', '4', '5', '6',
        '7', '8', '9', '10', '11', '12',
        '13', '14', '15', '16', '17', '18', '19', '20',


        '21', '22', '23', '24', '25', '26',
        '27', '28', '29', '30', '31', '32',
        '33', '34', '35', '36', '37', '38', '39', '40'
      ],
      seatReserved: [],
      bus_type: '',
      source: '',
      destination: '',
      ddate: '',
      arrival_time: '',
      fare: '',
      busdetail: []
    }
  }
  componentWillMount() {
    const booked = JSON.parse(localStorage.getItem('bookedseat'))
    this.setState({ busdetail: booked })
    this.setState({ bus_type: booked.bus_type })
    this.setState({ source: booked.source })
    this.setState({ destination: booked.destination })
    this.setState({ ddate: booked.ddate })
    this.setState({ arrival_time: booked.arrival_time })
    this.setState({ fare: booked.fare })
  }
  onClickData(seat) {
    if (this.state.seatReserved.indexOf(seat) > -1) {
      this.setState({
        seatAvailable: this.state.seatAvailable.concat(seat),
        seatReserved: this.state.seatReserved.filter(res => res != seat)
      })
    } else {
      this.setState({
        seatReserved: this.state.seatReserved.concat(seat),
        seatAvailable: this.state.seatAvailable.filter(res => res != seat)
      })
    }
  }

  render() {
    //console.log(this.state.bus_type)
    return (
      <div >
        <h5>Proceed to Select Your Seat</h5>
        <DrawGrid
          seat={this.state.seat}
          available={this.state.seatAvailable}
          reserved={this.state.seatReserved}
          onClickData={this.onClickData.bind(this)}
          bus_type={this.state.bus_type}
          name={this.state.name}
          phone_no={this.state.phone_no}
          fare={this.state.fare}
          arrival_time={this.state.arrival_time}
          ddate={this.state.ddate}
          source={this.state.source}
          destination={this.state.destination}

        />
      </div>
    )
  }
}




export default BookSeat;