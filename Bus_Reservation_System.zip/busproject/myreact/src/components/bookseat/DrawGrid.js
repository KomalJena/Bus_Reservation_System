import React from 'react';
import ReservedList from './ReservedList';
import AvailableList from './AvailableList';
import { Link } from "react-router-dom";


export default class DrawGrid extends React.Component {
    render() {
      return (
        <div className="container">
          <h2></h2>
          <table className="grid">
            <tbody>
              <tr>
                {this.props.seat.map(row =>
                  <td
                    className={this.props.reserved.indexOf(row) > -1 ? 'reserved' : 'available'}
                    key={row} onClick={e => this.onClickSeat(row)}>{row} </td>)}
              </tr>
            </tbody>
          </table>
  
          <AvailableList available={this.props.available} />
          <ReservedList reserved={this.props.reserved} />
         
          <table className="table buslistitem">
            <thead>
              <tr className="text-center">
                <th>Bus_Type</th>
                <th>Name</th>
                <th>Phone_No</th>
                <th>Selected Seat</th>
                <th>Fare</th>
                <th>Arrival Time</th>
                <th>Date</th>
                <th>from</th>
                <th>Destination</th>
              </tr>
              <tr className="text-center" style={{ fontSize: "16px" }}>
  
                <td>{this.props.bus_type}</td>
                <td>Jagriti Bhardwaj</td>
                <td>1234567891</td>
                <td>{this.props.reserved}</td>
                <td>{(this.props.reserved.length) * (this.props.fare)}</td>
                <td>{this.props.arrival_time}</td>
                <td>{this.props.ddate}</td>
                <td>{this.props.source}</td>
                <td>{this.props.destination}</td>
              </tr>
            </thead>
          </table>
          <Link to='./creditcard'><button className='btn'>Payment</button></Link>
        </div>
  
      )
    }
  
    onClickSeat(seat) {
      this.props.onClickData(seat);
  
  
    }
  }