import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Button, Form, FormGroup, Label, Jumbotron, Input } from 'reactstrap';
import axios from 'axios';

export default class Signup extends Component {

  componentDidMount() {

    window.scrollTo(0, 0)

  }

  constructor(props) {
    super(props);
    this.state = {
      user_email: '',
      user_name: '',
      mobile_no: '',
      password: '',
      errors: {}
    }

    this.handleChangeName = this.handleChangeName.bind(this);
    this.handleChangeMobile = this.handleChangeMobile.bind(this);
    this.handleChangeEmail = this.handleChangeEmail.bind(this);
    this.handleChangePassword = this.handleChangePassword.bind(this);
    this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);

  }
  
  handleChangeName(e) {
    this.setState({ user_name: e.target.value });
  }

  handleChangeEmail(e) {
    this.setState({ user_email: e.target.value });
  }

  handleChangeMobile(e) {
    this.setState({ mobile_no: e.target.value });
  }

  handleChangePassword(e) {
    this.setState({ password: e.target.value });
  }
  submituserRegistrationForm(e) {
    e.preventDefault();
    if (this.validateForm()) {
      let fields = {};
      fields["user_name"] = "";
      fields["user_email"] = "";
      fields["mobile_no"] = "";
      fields["password"] = "";
      this.setState({ fields: fields });

      const userObject = {
        user_name: this.state.user_name,
        mobile_no: this.state.mobile_no,
        user_email:this.state.user_email,
        password:this.state.password
        
    };

      axios.post('http://localhost:4000/postMessages', userObject)
        .then((res) => {
          console.log(res.data)
          console.log(userObject);
        }).catch((error) => {
          console.log(error)
        });
    }

  }

    validateForm() {

        let fields = this.state.fields;
        let errors = {};
        let formIsValid = true;

        if (!fields["user_email"]) {
            formIsValid = false;
            errors["user_email"] = "*Please enter your email-ID.";
        }

        if (typeof fields["user_email"] !== "undefined") {
            //regular expression for email validation
            var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+))|("[\w-\s]+")([\w-]+(?:\.[\w-]+)))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
            if (!pattern.test(fields["user_email"])) {
                formIsValid = false;
                errors["user_email"] = "*Please enter valid email-ID.";
            }
        }

        if (!fields["password"]) {
            formIsValid = false;
            errors["password"] = "*Please enter your password.";
        }

        if (typeof fields["password"] !== "undefined") {
            if (!fields["password"].match(/^.(?=.{8,})(?=.\d)(?=.[a-z])(?=.[A-Z])(?=.[@#$%&]).$/)) {
                formIsValid = false;
                errors["password"] = "*Please enter secure and strong password.";
            }
        }

        this.setState({
            errors: errors
        });
        return formIsValid;
    }

    render() {
        console.log(this.state.user_email)
        console.log()

        return (
            <div class="main-w3layouts wrapper">
                <h1>SignUp Form</h1>
                <div class="main-agileinfo">
                    <div class="agileits-top">
                        <form action="#" method="post" onSubmit={this.submituserRegistrationForm}>
                            <input class="text" type="text" name="Username" placeholder="Username"  value={this.state.user_name} onChange={this.handleChangeName}  required="" />
                            <input class="text email" type="email" name="email" placeholder="Email"  value={this.state.user_email} onChange={this.handleChangeEmail} required="" />
                            <input class="text" type="password" name="password" placeholder="Password" value={this.state.password} onChange={this.handleChangePassword} required="" />
                            <input class="text w3lpass" type="text" name="mobile" placeholder="Mobile"  value={this.state.mobile_no} onChange={this.handleChangeMobile} required="" />
                            <div class="wthree-text">
                                <label class="anim">
                                    <input type="checkbox" class="checkbox" required="" />
                                    <span>I Agree To The Terms & Conditions</span>
                                </label>
                                <div class="clear"> </div>
                            </div>
                            <input type="submit" value="SIGNUP" />
                        </form>
                        <p>Don't have an Account? <a href="#"> Login Now!</a></p>
                    </div>
                </div>
                <div class="colorlibcopy-agile">
                    <p>© 2018 Colorlib Signup Form. All rights reserved | Design by <a href="https://colorlib.com/" target="_blank">Colorlib</a></p>
                </div>
            </div>
        );
    }
}




