
import React, { Component } from 'react';

export default class CreateUser extends Component {
    render() {
        return (
            <div>
                <p>Create User Component!!</p>
            </div>
        )
    }
}