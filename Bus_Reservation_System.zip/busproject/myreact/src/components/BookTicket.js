import React from 'react';
import '../style/BookTicket.css';
import axios from 'axios';
import { Link } from 'react-router-dom';

class Planbooking extends React.Component {
    state = {
        startDate: new Date(),
        usersCollection: [],
    };

    componentWillMount() {

        // this.setState(this.baseState)
        axios.get('http://localhost:4000/postBookticket')
            .then(res => {
                this.setState({ usersCollection: res.data })
                // console.log(res.data);

            })
            .catch(function (error) {
                console.log(error);
            })

    }


    handleChange = date => {
        this.setState({
            startDate: date
        });
    };

    onSubmit(e) {
        e.preventDefault()
        
    }

    render() {

        return (
            <div id="booking" class="section">
                <div class="section-center">
                    <div class="container">
                        <div class="row">
                            <div class="booking-form">
                                <form onSubmit={this.onSubmit}>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">from</span>
                                                <select className="form-control" id="source" type="text" onChange={(e) => localStorage.setItem('from', e.target.value)} placeholder="City or bus-station">
                                                    <option value="Bangalore">Bangalore</option>
                                                    <option value="Mangalore">Karnataka</option>
                                                    <option value="Chennai">Chennai</option>
                                                    <option value="Pondicherry">Pondicherry</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <span class="form-label">to</span>
                                                {/* <input class="form-control" type="text" placeholder="City or bus-station" /> */}
                                                <select className="form-control" id="source" type="text" onChange={(e) => localStorage.setItem('to', e.target.value)} placeholder="City or bus-station" >
                                                    <option value="Bangalore">Bangalore</option>
                                                    <option value="Mangalore">Mangalore</option>
                                                    <option value="Chennai">Chennai</option>
                                                    <option value="Pondicherry">Pondicherry</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <span class="form-label">Date</span>
                                                <input class="form-control" type="date" required />
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-btn">
                                                <Link to='/schedule' ><button class="submit-btn">Show Bus</button></Link>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Planbooking;