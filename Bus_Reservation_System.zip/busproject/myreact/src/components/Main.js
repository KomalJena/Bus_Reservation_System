import React,{ Component } from 'react';
import { Switch, Route, BrowserRouter } from 'react-router-dom';
import Signup from './signup';
import Navbar from './Navbar';
import Bookseat from './bookseat/BookSeats';
import Login from './Login';
import Schedule from './Schedule';
import Planbooking from './BookTicket';
import Creditcard from './creditcard';

class Landingpage extends Component{
    render(){
        return(
            // <Navbar />
            <BrowserRouter>
            <Switch>
                <Route exact path="/" component={Navbar} />
                <Route path="/signup" component={Signup} />
                <Route exact path="/login" component={Login} />
                 <Route exact path="/planbooking" component={ Planbooking } />
                <Route exact path="/bookseat" component={Bookseat} />
                <Route exact path="/schedule" component={Schedule} />
                <Route exact path="/creditcard" component={Creditcard } />
            </Switch>
            </BrowserRouter>
        )
    }
}

export default Landingpage;