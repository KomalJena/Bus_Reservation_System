import React from 'react';
import { Link, Redirect } from "react-router-dom";
import '../style/login.css';
import axios from 'axios';
import { Button, Form, Input, Label, FormGroup } from 'reactstrap';


export default class login extends React.Component {
  constructor() {
    super();
    this.state = {
      usersCollection: [],
      fields: {},
      errors: {},
      modalShowErr: false,
      modalErrMsg: "Incorrect username or password!!!",
      user_email: "",
      password: ""
    }

    this.baseState = this.state
    this.handleChange = this.handleChange.bind(this);
    this.submituserRegistrationForm = this.submituserRegistrationForm.bind(this);

  };

  componentWillMount() {
    this.setState(this.baseState)
    axios.get('http://localhost:4000/postMessages')
      .then(res => {
        console.log(this.setState({ usersCollection: res.data })
        );

      })
      .catch(function (error) {
        console.log(error);
      })

  }

  handleChange(e) {
    ;
    this.setState({
      [e.target.name]: e.target.value
    });

  }

  submituserRegistrationForm(e) {
    e.preventDefault();
    let flag = 0;
    console.log(this.state.user_email)
    this.state.usersCollection.map((ele) => {
      if (this.state.user_email == ele.user_email && this.state.password == ele.password) {
        //  alert("login success");
        this.props.history.push("/planbooking")
        if (this.state.loggedIn === false) {
          return <Redirect to="/login" />
        }
      } else {

        flag = flag + 1;
      }
    })

    if (flag == this.state.usersCollection.length) {
      alert("please Signup Fisrt")

    }
  }

  validateForm() {

    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;

    if (!fields["user_email"]) {
      formIsValid = false;
      errors["user_email"] = "*Please enter your email-ID.";
    }

    if (typeof fields["user_email"] !== "undefined") {
      //regular expression for email validation
      var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+))|("[\w-\s]+")([\w-]+(?:\.[\w-]+)))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
      if (!pattern.test(fields["user_email"])) {
        formIsValid = false;
        errors["user_email"] = "*Please enter valid email-ID.";
      }
    }

    if (!fields["password"]) {
      formIsValid = false;
      errors["password"] = "*Please enter your password.";
    }

    if (typeof fields["password"] !== "undefined") {
      if (!fields["password"].match(/^.(?=.{8,})(?=.\d)(?=.[a-z])(?=.[A-Z])(?=.[@#$%&]).$/)) {
        formIsValid = false;
        errors["password"] = "*Please enter secure and strong password.";
      }
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
  }

  render() {
    console.log(this.state.user_email)
    console.log()
    return (
      <div className="container">
        <div className="row">
          <div className="col-md-4 login-sec">
            <h2 className="text-center">Login</h2>
            <Form method="post" name="userRegistrationForm" onSubmit={this.submituserRegistrationForm} >

              <FormGroup>
                <Label for="exampleEmail">Email</Label>
                <Input type="email" name="user_email" id="exampleEmail" value={this.state.user_email} onChange={this.handleChange} placeholder="Enter a email" required />
                <div className="errorMsg">{this.state.errors.user_email}</div>
              </FormGroup>
              <FormGroup>
                <Label for="examplePassword">Password</Label>
                <Input type="password" name="password" id="examplePassword" value={this.state.password} onChange={this.handleChange} placeholder="Enter a password" required />
                <div className="errorMsg">{this.state.errors.password}</div>
              </FormGroup>
              <div className="d-flex justify-content-center mt-3 login_container">
                <Button type="submit" className="btn btn-login" >Submit</Button>
              </div>
            </Form>
            <br />
            <div className="d-flex justify-content-center mt-3 login_container">
              <Link to="/signup" id="Signup-Btn" ><h6>New user?</h6></Link>
            </div>
          </div>
        </div>
      </div>
    );
  }
}