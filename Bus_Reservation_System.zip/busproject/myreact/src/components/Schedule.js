import React, { Component } from 'react';
import axios from 'axios';
import '../style/Schedule.css';
//import '../style/Book.css';
import { Link } from 'react-router-dom';

class Schedule extends Component {
    constructor(props) {
        super(props) //since we are extending class Table so we have to use super in order to override Component class constructor
        this.state = {
            products: [],
            //showdata:false
            from: '',
            to: '',
            date: ''
        }
    }
    componentWillMount() {
        // this.setState(this.baseState)
        axios.get('http://localhost:4000/postBookticket')
            .then(res => {
                this.setState({ products: res.data })
                // console.log(res.data);

            })
            .catch(function (error) {
                console.log(error);
            })

        this.setState({ from: localStorage.getItem('from') })
        this.setState({ to: localStorage.getItem('to') })
        //  this.setState({date:localStorage.getItem('date')})

    }

    render() { //Whenever our class runs, render method will be called automatically, it may have already defined in the constructor behind the scene.
        return (
            <div className="container buslist">
                <div className="row">
                 {/* <div className="col-md-1"></div>  */}
                    {/* <div className="col-md-10 "> */}
                        <table className="table buslistitem">
                            <thead><tr className="text-center" style={{ textSize: "10px" }}><th>BUS Type</th>
                                <th>Source</th>
                                <th>Destination</th>
                                <th>Date</th>
                                <th>Arrival</th><th>Depart</th><th>Fare</th><th></th>
                            </tr></thead>
                            {
                                this.state.products.map(ele => {
                                    console.log(ele);
                                    return (
                                        this.state.from !== ele.source ? null : this.state.to !== ele.destination ? null :
                                            <>
                                                <tbody>
                                                    <tr className="text-center" style={{ fontSize: "16px" }}>
                                                        <td>{ele.bus_type}</td>
                                                        <td>{ele.source}</td>
                                                        <td>{ele.destination}</td>
                                                        <td>{ele.ddate}</td>
                                                        <td>{ele.departure_time}</td>
                                                        <td>{ele.arrival_time}</td>
                                                        <td>{ele.fare}</td>


                                                        <td><Link to='/bookseat'>
                                                            <button className="btn btn-primary btnsubmit" name={ele._id} onClick={() => {
                                                            localStorage.setItem('bookedseat', JSON.stringify(ele))
                                                        }}>View Seats</button></Link></td>
                                                    </tr>
                                                </tbody>
                                            </>
                                    )
                                })
                            }
                        </table>

                    {/* </div> */}
                    {/* <div className="col-md-1"></div> */}
                </div>

            </div>
        )
    }
}
export default Schedule;
