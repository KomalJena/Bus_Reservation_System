import React from 'react';
import { Link } from 'react-router-dom'
import '../style/Navbar.css';
//import bus from '../image/bus.png';

class Navbar extends React.Component {
    render() {
        return (
            
            <header class="site-navbar py-4 js-sticky-header site-navbar-target" role="banner">
           
                <div class="container-fluid">
                    <div class="d-flex align-items-center">
                        <div class="site-logo mr-auto w-25"><p>Go</p></div>
                        <div class="ml-auto w-25">
                            <nav class="site-navigation position-relative text-right" role="navigation">
                                <ul class="site-menu main-menu site-menu-dark js-clone-nav mr-auto d-none d-lg-block m-0 p-0">
                                    <li class="cta"><Link to="/signup" class="nav-link">Signup<span></span></Link></li>
                                    <li class="cta"><Link to="/login" class="nav-link">Login<span></span></Link></li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
                {/* <img src={bus} alt="Logo" /> */}
            </header>
        )
    }
}

export default Navbar;
