import React from 'react';
import { Link } from "react-router-dom";
import { Form ,FormGroup, Input, Button, Label} from 'reactstrap';
import '../style/creditcard.css';
import axios from 'axios';
//import creditcard from '../image/creditcard.jpg';

export default class Creditcard extends React.Component {
  // componentDidMount() {

  //   window.scrollTo(0, 0)

  // }

  constructor(props) {
    super(props);
    this.state = {
      name: '',
      card_no: '',
      cvv: '',
      date:'',
      errors: {}
    }
    //console.log("hogaya hai");

    this.handleChangeName = this.handleChangeName.bind(this);
    this.handleChangeCardno = this.handleChangeCardno.bind(this);
    this.handleChangecvv = this.handleChangecvv.bind(this);
    this.handleChangeDate = this.handleChangeDate.bind(this);
    this.submituserPaymentForm = this.submituserPaymentForm.bind(this);

  }

  handleChangeName(e) {
    this.setState({ name: e.target.value });
  }

  handleChangeCardno(e) {
    this.setState({ card_no: e.target.value });
  }

  handleChangecvv(e) {
    this.setState({ cvv: e.target.value });
  }
  handleChangeDate(e) {
    this.setState({ date: e.target.value });
  }

  submituserPaymentForm(e) {
    e.preventDefault();
    if (this.validateForm()) {
      let fields = {};
      fields["name"] = "";
      fields["card_no"] = "";
      fields["cvv"] = ""
      this.setState({ fields: fields });
      alert("Payment Suuccessful");

    }

  }

  validateForm() {
    let errors = {};
    let formIsValid = true;

    if (!this.state.name) {
      formIsValid = false;
      errors["username"] = "*Please enter your username.";
    }

    if (typeof this.state.name !== "undefined") {
      if (!this.state.name.match(/^[a-zA-Z ]*$/)) {
        formIsValid = false;
        errors["username"] = "*Please enter alphabet characters only.";
      }

    }

    if (!this.state.card_no) {

      formIsValid = false;

      errors["card_no"] = "*Please enter your card_no";

    }

    if (typeof this.state.card_no !== "undefined") {

      if (!this.state.card_no.match(/^[0-9]{16}$/)) {

        formIsValid = false;
        errors["card_no"] = "*Please enter only 16-digit";
      }
    }
 
    if (!this.state.cvv) {

      formIsValid = false;

      errors["cvv"] = "*Please enter your cvv";

    }

    if (typeof this.state.cvv !== "undefined") {

      if (!this.state.cvv.match(/^[0-9]{3}$/)) {

        formIsValid = false;
        errors["cvv"] = "*Please enter valid cvv";
      }
    }
 
    this.setState({
      errors: errors
    });
    return formIsValid;
  }
  render() {
    return (
      <div>
        <div className="container">
          <div className="row">
            <div className="col-md-12 login-sec">
              <h4 className="text">Proceed to Pay</h4>
              <Form method="post" name="userPaymentForm" onSubmit={this.submituserPaymentForm}>
                <FormGroup>
                  <Label for="exampleName">Name</Label>
                  <Input type="text" name="name" id="name" value={this.state.name} onChange={this.handleChangeName} placeholder="Enter a name" required/>
                  <div className="errorMsg">{this.state.errors.name}</div>
                </FormGroup>
                <FormGroup>
                  <Label for="exampleCardno">Card Number</Label>
                  <Input type="text" name="card" id="exampleCardno" value={this.state.card_no} onChange={this.handleChangeCardno} placeholder="Enter a card_no" required/>
                  <div className="errorMsg">{this.state.errors.card_no}</div>
                </FormGroup>
                <FormGroup>
                  <Label for="exampleDate">Date</Label>
                  <Input type=" date" name="date" id="exampleDate" value={this.state.date} onChange={this.handleChangeDate} placeholder="Enter a date" required/>
                  <div className="errorMsg">{this.state.errors.date}</div>
                </FormGroup>
                <FormGroup>
                  <Label for="exampleCVV">CVV</Label>
                  <Input type="cvv" name="cvv" id="exampleCVV" value={this.state.cvv} onChange={this.handleChangecvv} placeholder="Enter a cvv" required/>
                  <div className="errorMsg">{this.state.errors.cvv}</div>
                </FormGroup>
                <div className="d-flex justify-content-center mt-3 login_container">

                 <Button type="submit" className="btn">Pay</Button>
                </div>
              </Form>
              
          </div>
        </div>
        </div>
        {/* <div className="card">
              <img src={creditcard} alt="card" />
            </div> */}
      </div>
    )
  }
}