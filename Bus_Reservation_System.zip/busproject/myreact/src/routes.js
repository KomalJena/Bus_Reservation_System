import React from "react";
import { Switch, Route } from "react-router-dom";

//components
import Main from "./components/Main";
import login from "./components/login";
import signup from "./components/signup";
import Book from "./components/Book";
import creditcard from "./components/creditcard";
import Thanks from "./components/Thanks";


const Routes = () => (
    <Switch>
        <Route exact path="/" component={Main} />
        <Route exact path="/login" component={login} />
        <Route exact path="/signup" component={signup} />
        <Route exact path="/Book" component={Book} />
        <Route exact path="/creditcard" component={creditcard} />
        <Route exact path="/thanks/:name" component={Thanks} />
    </Switch>
);

export default Routes;
